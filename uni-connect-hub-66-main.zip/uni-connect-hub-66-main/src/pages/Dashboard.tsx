import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, Users, Rocket, TrendingUp, Heart, Bell } from "lucide-react";

const stats = [
  { label: "Followed Societies", value: "8", icon: Users, color: "text-primary" },
  { label: "Upcoming Events", value: "5", icon: Calendar, color: "text-accent" },
  { label: "Applied Startups", value: "2", icon: Rocket, color: "text-warning" },
  { label: "Engagements", value: "142", icon: TrendingUp, color: "text-success" },
];

const upcomingEvents = [
  { title: "AI Workshop", date: "Apr 20", society: "Data Science Club" },
  { title: "Open Mic Night", date: "Apr 22", society: "Music Club" },
  { title: "Annual Hackathon", date: "Apr 25", society: "Tech Society" },
  { title: "Career Fair", date: "Apr 28", society: "Placement Cell" },
  { title: "Pitch Night", date: "May 2", society: "E-Cell" },
];

const recentNotifications = [
  { text: "Tech Society posted a new event", time: "2h ago" },
  { text: "Your startup application was accepted!", time: "5h ago" },
  { text: "Photography Club shared new photos", time: "1d ago" },
];

export default function Dashboard() {
  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Dashboard</h1>
        <p className="text-sm text-muted-foreground">Your campus activity at a glance</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((s) => (
          <Card key={s.label} className="shadow-card">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-secondary flex items-center justify-center">
                <s.icon className={`h-5 w-5 ${s.color}`} />
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{s.value}</p>
                <p className="text-xs text-muted-foreground">{s.label}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Upcoming Events */}
        <Card className="shadow-card">
          <CardHeader className="pb-3">
            <h3 className="font-semibold text-foreground flex items-center gap-2">
              <Calendar className="h-4 w-4 text-primary" /> Upcoming Events
            </h3>
          </CardHeader>
          <CardContent className="pt-0 space-y-3">
            {upcomingEvents.map((e) => (
              <div key={e.title} className="flex items-center justify-between py-2 border-b last:border-0">
                <div>
                  <p className="text-sm font-medium text-foreground">{e.title}</p>
                  <p className="text-xs text-muted-foreground">{e.society}</p>
                </div>
                <Badge variant="outline" className="text-xs">{e.date}</Badge>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Notifications */}
        <Card className="shadow-card">
          <CardHeader className="pb-3">
            <h3 className="font-semibold text-foreground flex items-center gap-2">
              <Bell className="h-4 w-4 text-primary" /> Recent Notifications
            </h3>
          </CardHeader>
          <CardContent className="pt-0 space-y-3">
            {recentNotifications.map((n, i) => (
              <div key={i} className="flex items-start gap-3 py-2 border-b last:border-0">
                <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <Heart className="h-3.5 w-3.5 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-foreground">{n.text}</p>
                  <p className="text-xs text-muted-foreground">{n.time}</p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
