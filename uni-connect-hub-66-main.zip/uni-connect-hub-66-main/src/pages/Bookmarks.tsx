import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bookmark, Calendar, MapPin, Trash2 } from "lucide-react";

const bookmarks = [
  { id: 1, title: "Annual Hackathon 2026", society: "Tech Society", date: "Apr 25", location: "Engineering Block A", category: "Competition" },
  { id: 2, title: "AI Workshop", society: "Data Science Club", date: "Apr 20", location: "CS Lab 301", category: "Workshop" },
  { id: 3, title: "Career Fair 2026", society: "Placement Cell", date: "Apr 28", location: "Convention Hall", category: "Seminar" },
];

export default function Bookmarks() {
  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
          <Bookmark className="h-6 w-6 text-primary" /> Bookmarks
        </h1>
        <p className="text-sm text-muted-foreground">Your saved events and posts</p>
      </div>

      <div className="space-y-3">
        {bookmarks.map((b) => (
          <Card key={b.id} className="shadow-card">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="h-12 w-12 rounded-lg gradient-primary flex items-center justify-center flex-shrink-0">
                <Calendar className="h-5 w-5 text-primary-foreground" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold text-sm text-foreground">{b.title}</h3>
                <p className="text-xs text-muted-foreground">{b.society}</p>
                <div className="flex gap-3 mt-1 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1"><Calendar className="h-3 w-3" /> {b.date}</span>
                  <span className="flex items-center gap-1"><MapPin className="h-3 w-3" /> {b.location}</span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="text-xs">{b.category}</Badge>
                <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-destructive">
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
