import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Bell, Calendar, Users, Rocket, Heart, Check } from "lucide-react";

const notifications = [
  { id: 1, icon: Calendar, text: "Tech Society posted a new event: Annual Hackathon 2026", time: "2 hours ago", read: false },
  { id: 2, icon: Rocket, text: "Your request to join CampusEats was accepted!", time: "5 hours ago", read: false },
  { id: 3, icon: Heart, text: "Photography Club liked your comment", time: "8 hours ago", read: false },
  { id: 4, icon: Users, text: "Music Club is hosting Open Mic Night tomorrow", time: "1 day ago", read: true },
  { id: 5, icon: Calendar, text: "Reminder: AI Workshop starts in 2 days", time: "1 day ago", read: true },
  { id: 6, icon: Rocket, text: "New startup idea posted: GreenCampus", time: "2 days ago", read: true },
];

export default function Notifications() {
  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <Bell className="h-6 w-6 text-primary" /> Notifications
          </h1>
          <p className="text-sm text-muted-foreground">Stay updated with campus activity</p>
        </div>
        <Button variant="outline" size="sm"><Check className="h-3.5 w-3.5 mr-1" /> Mark all read</Button>
      </div>

      <div className="space-y-2">
        {notifications.map((n) => (
          <Card key={n.id} className={`shadow-card transition-colors ${!n.read ? "border-primary/20 bg-primary/5" : ""}`}>
            <CardContent className="p-4 flex items-start gap-3">
              <div className={`h-9 w-9 rounded-full flex items-center justify-center flex-shrink-0 ${!n.read ? "gradient-primary" : "bg-secondary"}`}>
                <n.icon className={`h-4 w-4 ${!n.read ? "text-primary-foreground" : "text-muted-foreground"}`} />
              </div>
              <div className="flex-1 min-w-0">
                <p className={`text-sm ${!n.read ? "text-foreground font-medium" : "text-muted-foreground"}`}>{n.text}</p>
                <p className="text-xs text-muted-foreground mt-1">{n.time}</p>
              </div>
              {!n.read && <div className="h-2 w-2 rounded-full bg-primary mt-2 flex-shrink-0" />}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
