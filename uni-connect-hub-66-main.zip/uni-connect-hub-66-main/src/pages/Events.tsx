import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Calendar, MapPin, Users, Search, Filter } from "lucide-react";

const categories = ["All", "Competition", "Seminar", "Social", "Workshop", "Cultural", "Sports"];

const events = [
  { id: 1, title: "Annual Hackathon 2026", society: "Tech Society", date: "Apr 25, 2026", time: "9:00 AM", location: "Engineering Block A", category: "Competition", interested: 89, description: "48 hours of coding and innovation. Open to all departments." },
  { id: 2, title: "AI & ML Workshop", society: "Data Science Club", date: "Apr 20, 2026", time: "2:00 PM", location: "CS Lab 301", category: "Workshop", interested: 45, description: "Hands-on workshop on building ML models with Python." },
  { id: 3, title: "Startup Pitch Night", society: "E-Cell", date: "May 2, 2026", time: "6:00 PM", location: "Business Auditorium", category: "Seminar", interested: 52, description: "Pitch your startup idea to investors and mentors." },
  { id: 4, title: "Open Mic Night", society: "Music Club", date: "Apr 22, 2026", time: "7:00 PM", location: "Central Amphitheatre", category: "Cultural", interested: 120, description: "Showcase your musical talent on campus." },
  { id: 5, title: "Career Fair 2026", society: "Placement Cell", date: "Apr 28, 2026", time: "10:00 AM", location: "Convention Hall", category: "Seminar", interested: 300, description: "Meet top recruiters and explore career opportunities." },
  { id: 6, title: "Football Tournament", society: "Sports Committee", date: "May 5, 2026", time: "8:00 AM", location: "Main Ground", category: "Sports", interested: 200, description: "Inter-department football championship." },
];

const categoryColors: Record<string, string> = {
  Competition: "bg-destructive/10 text-destructive",
  Seminar: "bg-info/10 text-info",
  Social: "bg-accent/10 text-accent-foreground",
  Workshop: "bg-warning/10 text-warning",
  Cultural: "bg-primary/10 text-primary",
  Sports: "bg-success/10 text-success",
};

export default function Events() {
  const [activeCategory, setActiveCategory] = useState("All");
  const [searchQuery, setSearchQuery] = useState("");

  const filtered = events.filter((e) => {
    const matchCat = activeCategory === "All" || e.category === activeCategory;
    const matchSearch = e.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      e.society.toLowerCase().includes(searchQuery.toLowerCase());
    return matchCat && matchSearch;
  });

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Events</h1>
          <p className="text-sm text-muted-foreground">Discover and join campus events</p>
        </div>
        <Button className="gradient-primary text-primary-foreground border-0">
          <Calendar className="h-4 w-4 mr-2" /> Create Event
        </Button>
      </div>

      {/* Search & Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search events..."
            className="pl-9"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <Button variant="outline" size="icon">
          <Filter className="h-4 w-4" />
        </Button>
      </div>

      {/* Category Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-1">
        {categories.map((cat) => (
          <Button
            key={cat}
            variant={activeCategory === cat ? "default" : "outline"}
            size="sm"
            className={activeCategory === cat ? "gradient-primary text-primary-foreground border-0" : ""}
            onClick={() => setActiveCategory(cat)}
          >
            {cat}
          </Button>
        ))}
      </div>

      {/* Events Grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((event) => (
          <Card key={event.id} className="shadow-card hover:shadow-elevated transition-all duration-300 cursor-pointer group overflow-hidden">
            <div className="h-32 gradient-hero opacity-80 group-hover:opacity-100 transition-opacity flex items-center justify-center">
              <Calendar className="h-10 w-10 text-primary-foreground/60" />
            </div>
            <CardContent className="p-4 space-y-3">
              <div className="flex items-start justify-between">
                <Badge className={categoryColors[event.category] || ""}>{event.category}</Badge>
                <span className="text-xs text-muted-foreground flex items-center gap-1">
                  <Users className="h-3 w-3" /> {event.interested}
                </span>
              </div>
              <div>
                <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors">{event.title}</h3>
                <p className="text-xs text-muted-foreground mt-1">{event.society}</p>
              </div>
              <p className="text-xs text-muted-foreground line-clamp-2">{event.description}</p>
              <div className="flex flex-col gap-1 text-xs text-muted-foreground">
                <span className="flex items-center gap-1"><Calendar className="h-3 w-3" /> {event.date} · {event.time}</span>
                <span className="flex items-center gap-1"><MapPin className="h-3 w-3" /> {event.location}</span>
              </div>
              <Button size="sm" className="w-full gradient-primary text-primary-foreground border-0">
                I'm Interested
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
