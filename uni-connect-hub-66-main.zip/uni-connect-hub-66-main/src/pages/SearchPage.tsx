import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Search, Calendar, Users, Rocket, User } from "lucide-react";

const tabs = ["All", "Events", "Societies", "People", "Startups"];

const results = [
  { type: "event", title: "Annual Hackathon 2026", sub: "Tech Society · Apr 25", icon: Calendar },
  { type: "society", title: "Photography Club", sub: "230 members · Creative", icon: Users },
  { type: "people", title: "Sarah Kim", sub: "CS · Developer, Designer", icon: User },
  { type: "startup", title: "EduSync", sub: "by Sarah K. · Open", icon: Rocket },
  { type: "event", title: "Career Fair 2026", sub: "Placement Cell · Apr 28", icon: Calendar },
  { type: "society", title: "Entrepreneurship Cell", sub: "320 members · Business", icon: Users },
  { type: "people", title: "Mike Rodriguez", sub: "Business · Marketer", icon: User },
  { type: "startup", title: "CampusEats", sub: "by Mike R. · Open", icon: Rocket },
];

export default function SearchPage() {
  const [activeTab, setActiveTab] = useState("All");
  const [query, setQuery] = useState("");

  const filtered = results.filter((r) => {
    const matchTab = activeTab === "All" || r.type.toLowerCase() === activeTab.toLowerCase().replace("ies", "y").replace("s", "").replace("peop", "people");
    const matchQuery = !query || r.title.toLowerCase().includes(query.toLowerCase());
    return matchTab && matchQuery;
  });

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Search & Discover</h1>
        <p className="text-sm text-muted-foreground">Find events, societies, people, and startups</p>
      </div>

      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
        <Input placeholder="Search anything..." className="pl-12 h-12 text-base" value={query} onChange={(e) => setQuery(e.target.value)} />
      </div>

      <div className="flex gap-2 overflow-x-auto">
        {tabs.map((t) => (
          <Button key={t} variant={activeTab === t ? "default" : "outline"} size="sm"
            className={activeTab === t ? "gradient-primary text-primary-foreground border-0" : ""}
            onClick={() => setActiveTab(t)}>{t}</Button>
        ))}
      </div>

      <div className="space-y-2">
        {filtered.map((r, i) => (
          <Card key={i} className="shadow-card hover:shadow-soft transition-shadow cursor-pointer">
            <CardContent className="p-4 flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-secondary flex items-center justify-center">
                <r.icon className="h-5 w-5 text-primary" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-foreground">{r.title}</p>
                <p className="text-xs text-muted-foreground">{r.sub}</p>
              </div>
              <Badge variant="outline" className="text-xs capitalize">{r.type}</Badge>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
