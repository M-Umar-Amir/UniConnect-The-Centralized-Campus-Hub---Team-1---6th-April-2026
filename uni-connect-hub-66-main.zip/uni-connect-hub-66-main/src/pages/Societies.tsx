import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Users, Search, Calendar, UserPlus } from "lucide-react";
import { useState } from "react";

const societies = [
  { id: 1, name: "Tech Society", avatar: "TS", members: 450, events: 12, category: "Technology", description: "Building the future, one line of code at a time.", followed: true },
  { id: 2, name: "Photography Club", avatar: "PC", members: 230, events: 8, category: "Creative", description: "Capturing campus life through our lenses.", followed: false },
  { id: 3, name: "Entrepreneurship Cell", avatar: "EC", members: 320, events: 15, category: "Business", description: "Fostering innovation and startup culture on campus.", followed: true },
  { id: 4, name: "Music Club", avatar: "MC", members: 180, events: 6, category: "Cultural", description: "Where melodies meet passion. Open jams every Friday!", followed: false },
  { id: 5, name: "Sports Committee", avatar: "SC", members: 500, events: 20, category: "Sports", description: "Organizing inter-department tournaments and fitness events.", followed: false },
  { id: 6, name: "Literary Society", avatar: "LS", members: 150, events: 5, category: "Creative", description: "For book lovers, writers, and poets. Weekly reading circles.", followed: true },
  { id: 7, name: "Data Science Club", avatar: "DS", members: 200, events: 10, category: "Technology", description: "Exploring data, one dataset at a time.", followed: false },
  { id: 8, name: "Debate Society", avatar: "DB", members: 120, events: 7, category: "Academic", description: "Sharpening minds through structured debate and discussion.", followed: false },
];

export default function Societies() {
  const [searchQuery, setSearchQuery] = useState("");
  const filtered = societies.filter((s) =>
    s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Societies</h1>
          <p className="text-sm text-muted-foreground">Explore and follow campus communities</p>
        </div>
      </div>

      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search societies..."
          className="pl-9"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {filtered.map((s) => (
          <Card key={s.id} className="shadow-card hover:shadow-elevated transition-all duration-300 group">
            <CardContent className="p-5 text-center space-y-3">
              <div className="h-16 w-16 rounded-2xl gradient-primary flex items-center justify-center mx-auto group-hover:scale-105 transition-transform">
                <span className="text-lg font-bold text-primary-foreground">{s.avatar}</span>
              </div>
              <div>
                <h3 className="font-semibold text-foreground">{s.name}</h3>
                <Badge variant="secondary" className="text-xs mt-1">{s.category}</Badge>
              </div>
              <p className="text-xs text-muted-foreground line-clamp-2">{s.description}</p>
              <div className="flex justify-center gap-4 text-xs text-muted-foreground">
                <span className="flex items-center gap-1"><Users className="h-3 w-3" /> {s.members}</span>
                <span className="flex items-center gap-1"><Calendar className="h-3 w-3" /> {s.events} events</span>
              </div>
              <Button
                size="sm"
                className={s.followed ? "w-full" : "w-full gradient-primary text-primary-foreground border-0"}
                variant={s.followed ? "outline" : "default"}
              >
                {s.followed ? "Following" : <><UserPlus className="h-3.5 w-3.5 mr-1" /> Follow</>}
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
