import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Heart, MessageCircle, Share2, Bookmark, MoreHorizontal, Calendar, MapPin } from "lucide-react";

const feedPosts = [
  {
    id: 1,
    society: "Tech Society",
    avatar: "TS",
    time: "2 hours ago",
    type: "event" as const,
    title: "Annual Hackathon 2026",
    description: "Join us for 48 hours of coding, collaboration, and innovation! Open to all departments. Prizes worth $5,000.",
    date: "Apr 25, 2026",
    location: "Engineering Block A",
    category: "Competition",
    likes: 142,
    comments: 28,
    interested: 89,
  },
  {
    id: 2,
    society: "Photography Club",
    avatar: "PC",
    time: "5 hours ago",
    type: "post" as const,
    title: "Campus Photo Walk Highlights 📸",
    description: "What an amazing turnout at yesterday's photo walk! Here are some highlights from our members. Stay tuned for the gallery drop this weekend.",
    likes: 234,
    comments: 45,
  },
  {
    id: 3,
    society: "Entrepreneurship Cell",
    avatar: "EC",
    time: "1 day ago",
    type: "event" as const,
    title: "Startup Pitch Night",
    description: "Got a startup idea? Pitch it to our panel of investors and mentors. Top 3 ideas get seed funding!",
    date: "May 2, 2026",
    location: "Business School Auditorium",
    category: "Seminar",
    likes: 98,
    comments: 16,
    interested: 52,
  },
  {
    id: 4,
    society: "Cultural Committee",
    avatar: "CC",
    time: "1 day ago",
    type: "post" as const,
    title: "Spring Fest Recap 🎉",
    description: "What a week it was! From dance battles to music nights, Spring Fest 2026 was unforgettable. Thank you to everyone who made it possible.",
    likes: 567,
    comments: 89,
  },
];

const trendingEvents = [
  { title: "AI Workshop", society: "Tech Society", date: "Apr 20" },
  { title: "Open Mic Night", society: "Music Club", date: "Apr 22" },
  { title: "Career Fair", society: "Placement Cell", date: "Apr 28" },
];

export default function HomeFeed() {
  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Welcome back, John! 👋</h1>
          <p className="text-muted-foreground text-sm mt-1">Here's what's happening on campus</p>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Feed */}
        <div className="lg:col-span-2 space-y-4">
          {feedPosts.map((post) => (
            <Card key={post.id} className="shadow-card hover:shadow-soft transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full gradient-primary flex items-center justify-center">
                      <span className="text-xs font-bold text-primary-foreground">{post.avatar}</span>
                    </div>
                    <div>
                      <p className="font-semibold text-sm text-foreground">{post.society}</p>
                      <p className="text-xs text-muted-foreground">{post.time}</p>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="pt-0 space-y-3">
                <div>
                  <h3 className="font-semibold text-foreground">{post.title}</h3>
                  <p className="text-sm text-muted-foreground mt-1 leading-relaxed">{post.description}</p>
                </div>
                {post.type === "event" && (
                  <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1"><Calendar className="h-3.5 w-3.5" /> {post.date}</span>
                    <span className="flex items-center gap-1"><MapPin className="h-3.5 w-3.5" /> {post.location}</span>
                    <Badge variant="secondary" className="text-xs">{post.category}</Badge>
                  </div>
                )}
                <div className="flex items-center justify-between pt-2 border-t">
                  <div className="flex items-center gap-1">
                    <Button variant="ghost" size="sm" className="h-8 text-muted-foreground hover:text-primary gap-1.5">
                      <Heart className="h-4 w-4" /> {post.likes}
                    </Button>
                    <Button variant="ghost" size="sm" className="h-8 text-muted-foreground hover:text-primary gap-1.5">
                      <MessageCircle className="h-4 w-4" /> {post.comments}
                    </Button>
                    <Button variant="ghost" size="sm" className="h-8 text-muted-foreground hover:text-primary">
                      <Share2 className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="flex items-center gap-1">
                    {post.type === "event" && (
                      <Button size="sm" className="h-8 gradient-primary text-primary-foreground border-0 text-xs">
                        Interested ({post.interested})
                      </Button>
                    )}
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground">
                      <Bookmark className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Sidebar */}
        <div className="space-y-4">
          <Card className="shadow-card">
            <CardHeader className="pb-3">
              <h3 className="font-semibold text-sm text-foreground">🔥 Trending Events</h3>
            </CardHeader>
            <CardContent className="pt-0 space-y-3">
              {trendingEvents.map((e) => (
                <div key={e.title} className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-foreground">{e.title}</p>
                    <p className="text-xs text-muted-foreground">{e.society}</p>
                  </div>
                  <Badge variant="outline" className="text-xs">{e.date}</Badge>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="shadow-card">
            <CardHeader className="pb-3">
              <h3 className="font-semibold text-sm text-foreground">📢 Quick Actions</h3>
            </CardHeader>
            <CardContent className="pt-0 space-y-2">
              <Button variant="outline" className="w-full justify-start text-sm h-9" size="sm">
                <Calendar className="h-4 w-4 mr-2" /> Create Event
              </Button>
              <Button variant="outline" className="w-full justify-start text-sm h-9" size="sm">
                <Share2 className="h-4 w-4 mr-2" /> Share Post
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
