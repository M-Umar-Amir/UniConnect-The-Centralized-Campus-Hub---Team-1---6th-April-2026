import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Calendar, Users, Rocket, ArrowRight, Zap, Globe, Shield } from "lucide-react";

const features = [
  { icon: Calendar, title: "Event Hub", desc: "Discover and RSVP to campus events from all societies in one place." },
  { icon: Users, title: "Society Network", desc: "Follow your favorite societies and stay updated with announcements." },
  { icon: Rocket, title: "Startup Launchpad", desc: "Post ideas, find co-founders, and build your dream startup team." },
  { icon: Zap, title: "Real-time Feed", desc: "Get a live feed of events, posts, and highlights from across campus." },
  { icon: Globe, title: "Discovery", desc: "Search and filter events, societies, and people with powerful tools." },
  { icon: Shield, title: "Secure & Private", desc: "Your data is safe with role-based access and modern security." },
];

const stats = [
  { value: "50+", label: "Societies" },
  { value: "200+", label: "Events" },
  { value: "5K+", label: "Students" },
  { value: "100+", label: "Startups" },
];

export default function Landing() {
  return (
    <div className="min-h-screen bg-background">
      {/* Nav */}
      <nav className="fixed top-0 w-full z-50 glass border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-lg gradient-primary flex items-center justify-center">
              <span className="text-sm font-bold text-primary-foreground">U</span>
            </div>
            <span className="font-bold text-lg text-foreground">UniConnect</span>
          </div>
          <div className="flex items-center gap-3">
            <Link to="/home">
              <Button variant="ghost" size="sm">Log in</Button>
            </Link>
            <Link to="/home">
              <Button size="sm" className="gradient-primary text-primary-foreground border-0">
                Get Started
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="pt-32 pb-20 px-4">
        <div className="max-w-4xl mx-auto text-center animate-fade-in">
          <div className="inline-flex items-center gap-2 bg-secondary rounded-full px-4 py-1.5 text-sm text-muted-foreground mb-6">
            <Zap className="h-3.5 w-3.5 text-primary" />
            Your campus, connected.
          </div>
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold text-foreground leading-tight mb-6">
            The Centralized{" "}
            <span className="bg-clip-text text-transparent" style={{ backgroundImage: "var(--gradient-hero)" }}>
              Campus Hub
            </span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-10">
            Connect with societies, discover events, launch startups, and build your campus network — all in one beautifully designed platform.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/home">
              <Button size="lg" className="gradient-primary text-primary-foreground border-0 text-base px-8">
                Explore Now <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
            <Button size="lg" variant="outline" className="text-base px-8">
              Learn More
            </Button>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-12 border-y bg-card">
        <div className="max-w-5xl mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((s) => (
            <div key={s.label} className="text-center">
              <div className="text-3xl font-bold text-primary">{s.value}</div>
              <div className="text-sm text-muted-foreground mt-1">{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-14">
            <h2 className="text-3xl font-bold text-foreground mb-3">Everything You Need</h2>
            <p className="text-muted-foreground max-w-xl mx-auto">
              One platform to manage your entire campus life — from events to startups.
            </p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((f) => (
              <div key={f.title} className="bg-card rounded-xl p-6 shadow-card hover:shadow-elevated transition-shadow duration-300 border">
                <div className="h-10 w-10 rounded-lg gradient-primary flex items-center justify-center mb-4">
                  <f.icon className="h-5 w-5 text-primary-foreground" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">{f.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-4">
        <div className="max-w-3xl mx-auto text-center gradient-hero rounded-2xl p-12">
          <h2 className="text-3xl font-bold text-primary-foreground mb-4">Ready to connect your campus?</h2>
          <p className="text-primary-foreground/80 mb-8 max-w-lg mx-auto">
            Join thousands of students already using UniConnect to make the most of university life.
          </p>
          <Link to="/home">
            <Button size="lg" variant="secondary" className="text-base px-8">
              Get Started Free <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-8 px-4">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="h-7 w-7 rounded-md gradient-primary flex items-center justify-center">
              <span className="text-xs font-bold text-primary-foreground">U</span>
            </div>
            <span className="font-semibold text-sm text-foreground">UniConnect</span>
          </div>
          <p className="text-xs text-muted-foreground">© 2026 UniConnect. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
