import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Rocket, Users, ArrowRight, Plus, Lightbulb } from "lucide-react";

const startups = [
  {
    id: 1, title: "EduSync", description: "An AI-powered study planner that syncs with your university timetable and suggests optimal study sessions.",
    founder: "Sarah K.", roles: ["Developer", "Designer"], applicants: 5, status: "Open",
  },
  {
    id: 2, title: "CampusEats", description: "A food ordering platform exclusively for campus cafeterias with pre-order and skip-the-line features.",
    founder: "Mike R.", roles: ["Developer", "Marketer", "Designer"], applicants: 12, status: "Open",
  },
  {
    id: 3, title: "GreenCampus", description: "Sustainability tracking app for universities — track carbon footprint, organize eco-drives, earn green points.",
    founder: "Alex T.", roles: ["Developer"], applicants: 3, status: "Open",
  },
  {
    id: 4, title: "SkillSwap", description: "Peer-to-peer skill exchange platform. Teach what you know, learn what you don't.",
    founder: "Priya M.", roles: ["Designer", "Marketer"], applicants: 8, status: "Open",
  },
  {
    id: 5, title: "UniRide", description: "Carpooling app for students commuting to campus. Share rides, split costs, reduce emissions.",
    founder: "James L.", roles: ["Developer", "Designer"], applicants: 6, status: "Closed",
  },
];

const roleColors: Record<string, string> = {
  Developer: "bg-primary/10 text-primary",
  Designer: "bg-accent/10 text-accent-foreground",
  Marketer: "bg-warning/10 text-warning",
};

export default function Launchpad() {
  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <Rocket className="h-6 w-6 text-primary" /> Founder's Launchpad
          </h1>
          <p className="text-sm text-muted-foreground">Post ideas, find co-founders, build your dream team</p>
        </div>
        <Button className="gradient-primary text-primary-foreground border-0">
          <Plus className="h-4 w-4 mr-2" /> Post Idea
        </Button>
      </div>

      {/* Banner */}
      <Card className="gradient-hero border-0 shadow-elevated">
        <CardContent className="p-6 flex items-center gap-4">
          <div className="h-12 w-12 rounded-xl bg-primary-foreground/20 flex items-center justify-center flex-shrink-0">
            <Lightbulb className="h-6 w-6 text-primary-foreground" />
          </div>
          <div className="flex-1">
            <h3 className="font-semibold text-primary-foreground">Got a startup idea?</h3>
            <p className="text-sm text-primary-foreground/80">Share it with the campus community and find the perfect team to bring it to life.</p>
          </div>
          <Button variant="secondary" size="sm" className="hidden sm:flex">
            Learn More <ArrowRight className="h-3.5 w-3.5 ml-1" />
          </Button>
        </CardContent>
      </Card>

      {/* Ideas Grid */}
      <div className="grid sm:grid-cols-2 gap-4">
        {startups.map((s) => (
          <Card key={s.id} className="shadow-card hover:shadow-elevated transition-all duration-300">
            <CardHeader className="pb-2">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-semibold text-foreground text-lg">{s.title}</h3>
                  <p className="text-xs text-muted-foreground">by {s.founder}</p>
                </div>
                <Badge variant={s.status === "Open" ? "default" : "secondary"} className={s.status === "Open" ? "gradient-primary text-primary-foreground border-0" : ""}>
                  {s.status}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-sm text-muted-foreground leading-relaxed">{s.description}</p>
              <div>
                <p className="text-xs font-medium text-foreground mb-1.5">Looking for:</p>
                <div className="flex flex-wrap gap-1.5">
                  {s.roles.map((r) => (
                    <Badge key={r} variant="secondary" className={`text-xs ${roleColors[r] || ""}`}>{r}</Badge>
                  ))}
                </div>
              </div>
              <div className="flex items-center justify-between pt-2 border-t">
                <span className="text-xs text-muted-foreground flex items-center gap-1">
                  <Users className="h-3 w-3" /> {s.applicants} applicants
                </span>
                {s.status === "Open" ? (
                  <Button size="sm" className="gradient-primary text-primary-foreground border-0">
                    Request to Join
                  </Button>
                ) : (
                  <Button size="sm" variant="outline" disabled>Closed</Button>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
