import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Edit, MapPin, GraduationCap, Calendar, Users, Rocket, LinkIcon } from "lucide-react";

const skills = ["React", "TypeScript", "UI/UX Design", "Python", "Machine Learning", "Node.js"];
const followedSocieties = ["Tech Society", "E-Cell", "Literary Society"];

export default function Profile() {
  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Header */}
      <Card className="shadow-card overflow-hidden">
        <div className="h-32 gradient-hero" />
        <CardContent className="relative pt-0 px-6 pb-6">
          <div className="flex flex-col sm:flex-row sm:items-end gap-4 -mt-10">
            <div className="h-20 w-20 rounded-2xl gradient-primary flex items-center justify-center border-4 border-card shadow-elevated">
              <span className="text-2xl font-bold text-primary-foreground">JD</span>
            </div>
            <div className="flex-1">
              <h1 className="text-xl font-bold text-foreground">John Doe</h1>
              <p className="text-sm text-muted-foreground">Computer Science · Class of 2027</p>
            </div>
            <Button variant="outline" size="sm">
              <Edit className="h-3.5 w-3.5 mr-1" /> Edit Profile
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Bio */}
      <Card className="shadow-card">
        <CardContent className="p-6 space-y-4">
          <h3 className="font-semibold text-foreground">About</h3>
          <p className="text-sm text-muted-foreground leading-relaxed">
            Full-stack developer and startup enthusiast. Passionate about building products that make campus life better.
            Currently working on EduSync — an AI-powered study planner.
          </p>
          <div className="flex flex-wrap gap-3 text-sm text-muted-foreground">
            <span className="flex items-center gap-1"><GraduationCap className="h-4 w-4" /> Stanford University</span>
            <span className="flex items-center gap-1"><MapPin className="h-4 w-4" /> California, USA</span>
            <span className="flex items-center gap-1"><LinkIcon className="h-4 w-4" /> johndoe.dev</span>
          </div>
        </CardContent>
      </Card>

      {/* Skills */}
      <Card className="shadow-card">
        <CardContent className="p-6 space-y-3">
          <h3 className="font-semibold text-foreground">Skills</h3>
          <div className="flex flex-wrap gap-2">
            {skills.map((s) => (
              <Badge key={s} variant="secondary" className="text-sm">{s}</Badge>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        <Card className="shadow-card">
          <CardContent className="p-4 text-center">
            <Users className="h-5 w-5 text-primary mx-auto mb-1" />
            <p className="text-xl font-bold text-foreground">3</p>
            <p className="text-xs text-muted-foreground">Societies</p>
          </CardContent>
        </Card>
        <Card className="shadow-card">
          <CardContent className="p-4 text-center">
            <Calendar className="h-5 w-5 text-accent mx-auto mb-1" />
            <p className="text-xl font-bold text-foreground">12</p>
            <p className="text-xs text-muted-foreground">Events</p>
          </CardContent>
        </Card>
        <Card className="shadow-card">
          <CardContent className="p-4 text-center">
            <Rocket className="h-5 w-5 text-warning mx-auto mb-1" />
            <p className="text-xl font-bold text-foreground">2</p>
            <p className="text-xs text-muted-foreground">Startups</p>
          </CardContent>
        </Card>
      </div>

      {/* Followed Societies */}
      <Card className="shadow-card">
        <CardContent className="p-6 space-y-3">
          <h3 className="font-semibold text-foreground">Following</h3>
          <div className="space-y-2">
            {followedSocieties.map((s) => (
              <div key={s} className="flex items-center justify-between py-2 border-b last:border-0">
                <div className="flex items-center gap-3">
                  <div className="h-8 w-8 rounded-lg gradient-primary flex items-center justify-center">
                    <span className="text-xs font-bold text-primary-foreground">{s.split(" ").map(w => w[0]).join("")}</span>
                  </div>
                  <span className="text-sm font-medium text-foreground">{s}</span>
                </div>
                <Button variant="outline" size="sm" className="text-xs h-7">Following</Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
